function updateDateTime() {
    const now = new Date();
    
  
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
  
    const ampm = hours >= 12 ? 'PM' : 'AM';
    

    hours = hours % 12;
    hours = hours ? hours : 12; 
    const formattedHours = String(hours).padStart(2, '0');
    

    const timeString = `${formattedHours}:${minutes}:${seconds}`;
    

    document.getElementById('timeDisplay').textContent = timeString;
    document.getElementById('ampm').textContent = ampm;
    
 
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                    'July', 'August', 'September', 'October', 'November', 'December'];
    
    const dayName = days[now.getDay()];
    const monthName = months[now.getMonth()];
    const day = now.getDate();
    const year = now.getFullYear();
    
    
    const dateString = `${dayName}, ${monthName} ${day}, ${year}`;
    
    
    document.getElementById('fullDate').textContent = dateString;
}

updateDateTime();


setInterval(updateDateTime, 1000);